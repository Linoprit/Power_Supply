# UniversalBoard4Nucleo
Universal Board for Nucleo by KiCAD

Nucleo_Universal_Board.zip is an order file for Elecrow.
http://www.elecrow.com/5pcs-2-layer-pcb-p-1174.html
